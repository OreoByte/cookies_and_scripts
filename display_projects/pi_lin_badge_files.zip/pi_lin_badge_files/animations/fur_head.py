import pygame
import random

# initialize pygame
pygame.init()

# set screen size
screen_width = 320
screen_height = 400
screen = pygame.display.set_mode((screen_width, screen_height))

# set font
font_size = 40
font_type = './fonts/sc2.tff'
font = pygame.font.Font(font_type, font_size)

# set text
text = "oreobyt3"
text_color = (255, 255, 255)

# load image (move up by - pixel number)
img = pygame.image.load("./img_files/ofur.jpg")
img_rect = img.get_rect(center=(screen_width/2, screen_height/2 - 20))

# set glitch effect parameters
glitch_offset = 5
glitch_speed = 40
max_glitch_size = 50
min_glitch_size = 10

# create a timer to trigger glitch effect
glitch_timer = pygame.time.Clock()
glitch_time = 0
glitch_duration = 0
#glitch_duration = 1300

# main loop
running = True
while running:
    # handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # clear screen (purple background color)
    screen.fill((36, 0, 72))

    # draw purple background (for the image that's being loaded)
    pygame.draw.rect(screen, (28, 0, 72), pygame.Rect(0, 0, screen_width, screen_height * 0.7))

    # render text
    text_surface = font.render(text, True, text_color)

    # set text position to centered bottom
    text_rect = text_surface.get_rect(midbottom=(screen_width/2, screen_height))

    # move text 20% above bottom
    text_rect.bottom = int(screen_height * 0.94)

    # draw image
    screen.blit(img, img_rect)

    # apply glitch effect
    if pygame.time.get_ticks() - glitch_time > glitch_duration:
        glitch_time = pygame.time.get_ticks()
        glitch_duration = random.randint(1750, 6210) # set random duration
        for i in range(random.randint(1, 3)):
            size = random.randint(min_glitch_size, max_glitch_size)
            x = random.randint(-glitch_offset, glitch_offset)
            y = random.randint(-glitch_offset, glitch_offset)
            offset_x = random.randint(-size, size)
            offset_y = random.randint(-size, size)
            screen.blit(text_surface, (text_rect.x + x + offset_x, text_rect.y + y + offset_y))
        pygame.display.flip()
        pygame.time.wait(glitch_speed)

    # draw text
    screen.blit(text_surface, text_rect)

    # add extra flare to glitch effect
    for i in range(random.randint(1, 3)):
        x = random.randint(0, screen_width)
        y = random.randint(0, screen_height)
        size = random.randint(1, 3)
        pygame.draw.rect(screen, (255, 255, 255), pygame.Rect(x, y, size, size))

    # update screen
    pygame.display.flip()

    # regulate FPS
    glitch_timer.tick(30)

# quit pygame
pygame.quit()
