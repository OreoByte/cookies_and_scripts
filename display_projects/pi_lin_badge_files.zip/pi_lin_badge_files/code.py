import subprocess
import time

# Define the two scripts to run
mp = "./animations/"
script1 = mp+'oreo_sona.py'
script2 = mp+'fur_head.py'
loop_time = 120

# Define a function to run a script for a certain amount of time
def run_script(script, duration):
    # Start the subprocess and get its process ID
    proc = subprocess.Popen(['python3', script])
    pid = proc.pid

    # Wait for the specified duration
    time.sleep(duration)

    # Terminate the subprocess
    subprocess.run(['kill', str(pid)])

# Run the scripts in an infinite loop
while True:
    # Run the first script for 5 seconds
    run_script(script1, loop_time)

    # Run the second script for 5 seconds
    run_script(script2, loop_time)

